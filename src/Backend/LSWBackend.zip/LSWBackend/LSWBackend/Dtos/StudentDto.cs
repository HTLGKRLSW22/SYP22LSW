﻿namespace LSWBackend.Dtos
{
    public class StudentDto
    {
        public int StudentId { get; set; }
        public string Username { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int ClazzId { get; set; }
    }
}
