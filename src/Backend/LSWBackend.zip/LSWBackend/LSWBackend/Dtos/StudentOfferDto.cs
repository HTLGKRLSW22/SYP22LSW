﻿namespace LSWBackend.Dtos
{
    public class StudentOfferDto
    {
        public int StudentOfferId { get; set; }
        public int StudentId { get; set; }
        public int OfferId { get; set; }
    }
}
