﻿using Backend.Dtos;
using ChinookPlaylists;
using LSWDbLib;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace LSWBackend.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class CourseController : ControllerBase
    {
        private CoursesService _service;

        public CourseController(CoursesService service)
        {
            _service = service;
        }

        [Authorize(Roles = "Teacher")]
        [HttpPut("{id}")]
        public ActionResult<OfferDto> EditCourse(int id, [FromBody] OfferDto offerDto)
        {
            if (id < 0 || offerDto == null) return BadRequest("Id or request body incorrect");
            var replyOffer = _service.EditCourse(id, offerDto);
            if (replyOffer == new Offer()) return BadRequest("No offer with provided id found");
            return Ok(new OfferDto().CopyPropertiesFrom(replyOffer));
        }


        [HttpGet("[action]")]
        public ActionResult<List<OfferDto>> GetTeacherCourses(int teacherId)
        {
            if (teacherId < 0) return BadRequest($"TeacherId {teacherId} not valid");
            return Ok(_service.GetTeacherCourses(teacherId)
                .Select(x => new OfferDto().CopyPropertiesFrom(x))
                .ToList());
        }



    }
}
